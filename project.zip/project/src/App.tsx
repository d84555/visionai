import React, { useState } from 'react';
import { AlertCircle, Camera, Clock, Database, Layout, Search } from 'lucide-react';
import VideoDisplay from './components/VideoDisplay';
import AlertDashboard from './components/AlertDashboard';
import EventLog from './components/EventLog';
import EventSummary from './components/EventSummary';
import Sidebar from './components/Sidebar';

function App() {
  const [activeTab, setActiveTab] = useState('video');

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 overflow-hidden">
        <div className="h-full p-6">
          {activeTab === 'video' && <VideoDisplay />}
          {activeTab === 'alerts' && <AlertDashboard />}
          {activeTab === 'events' && <EventLog />}
          {activeTab === 'summary' && <EventSummary />}
        </div>
      </main>
    </div>
  );
}

export default App;