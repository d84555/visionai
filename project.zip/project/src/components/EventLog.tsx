import React, { useState } from 'react';
import { Search, Calendar, Download } from 'lucide-react';

const EventLog = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const events = [
    { id: 1, timestamp: '2024-03-15 10:30:22', type: 'Object Detection', details: 'Vehicle detected in zone A' },
    { id: 2, timestamp: '2024-03-15 10:29:15', type: 'System Status', details: 'Camera connection established' },
    { id: 3, timestamp: '2024-03-15 10:28:03', type: 'Alert', details: 'Motion detected in restricted area' },
    { id: 4, timestamp: '2024-03-15 10:27:45', type: 'Object Detection', details: 'Person detected in zone B' },
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Event Log</h2>
        <div className="flex space-x-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Search events..."
              className="pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-2.5" />
          </div>
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow hover:bg-gray-50">
            <Calendar className="w-4 h-4 mr-2" />
            Filter Date
          </button>
          <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow hover:bg-gray-50">
            <Download className="w-4 h-4 mr-2" />
            Export
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow flex-1 overflow-hidden">
        <div className="overflow-auto h-full">
          {events.map((event) => (
            <div key={event.id} className="p-4 border-b hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-500">{event.timestamp}</span>
                <span className="px-3 py-1 bg-gray-100 rounded-full text-sm">{event.type}</span>
              </div>
              <p className="mt-2 text-gray-700">{event.details}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default EventLog;