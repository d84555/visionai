import React from 'react';

const Logo = () => {
  return (
    <div className="relative w-10 h-10">
      {/* Outer circle (camera lens) */}
      <div className="absolute inset-0 border-3 border-red-600 rounded-full"></div>
      
      {/* Inner circle (iris) */}
      <div className="absolute inset-2 bg-red-600 rounded-full"></div>
      
      {/* Circuit pattern (AI representation) */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-full h-[2px] bg-white rotate-45"></div>
        <div className="w-full h-[2px] bg-white -rotate-45"></div>
      </div>
      
      {/* Center dot (pupil) */}
      <div className="absolute inset-3 bg-white rounded-full"></div>
    </div>
  );
};

export default Logo;