import React, { useState, useRef, useEffect } from 'react';
import { Camera, Upload, Link, Play, Pause, X } from 'lucide-react';

const VideoDisplay = () => {
  const [videoSource, setVideoSource] = useState<string | null>(null);
  const [rtspUrl, setRtspUrl] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [showRtspInput, setShowRtspInput] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && videoSource) {
      try {
        videoRef.current.load();
        const playPromise = videoRef.current.play();
        if (playPromise !== undefined) {
          playPromise.catch(error => {
            console.error("Initial playback error:", error);
            setError("Error starting video playback. Please try again.");
          });
        }
      } catch (error) {
        console.error("Video loading error:", error);
        setError("Error loading video. Please try a different file.");
      }
    }
  }, [videoSource]);

  const validateVideoFile = (file: File): boolean => {
    const validTypes = ['video/mp4', 'video/webm', 'video/ogg'];
    if (!validTypes.includes(file.type)) {
      setError(`Unsupported video format. Please use ${validTypes.join(', ')}`);
      return false;
    }
    if (file.size > 500 * 1024 * 1024) { // 500MB limit
      setError("File size too large. Please use a video under 500MB.");
      return false;
    }
    return true;
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (validateVideoFile(file)) {
        if (videoSource?.startsWith('blob:')) {
          URL.revokeObjectURL(videoSource);
        }
        const url = URL.createObjectURL(file);
        setVideoSource(url);
        setIsPlaying(true);
        setError(null);
      }
    }
  };

  const handleRtspSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rtspUrl.trim()) {
      if (!rtspUrl.startsWith('rtsp://')) {
        setError("Invalid RTSP URL. URL must start with 'rtsp://'");
        return;
      }
      setVideoSource(rtspUrl);
      setShowRtspInput(false);
      setIsPlaying(true);
      setError(null);
    }
  };

  const handlePlayPause = () => {
    if (videoRef.current) {
      try {
        if (isPlaying) {
          videoRef.current.pause();
          setIsPlaying(false);
        } else {
          const playPromise = videoRef.current.play();
          if (playPromise !== undefined) {
            playPromise
              .then(() => setIsPlaying(true))
              .catch(error => {
                console.error("Playback error:", error);
                setError("Error playing video. Please try again.");
              });
          }
        }
      } catch (error) {
        console.error("Play/Pause error:", error);
        setError("Error controlling playback. Please try again.");
      }
    }
  };

  const handleVideoError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    const videoElement = e.currentTarget;
    let errorMessage = "Error loading video. Please check the file format and try again.";
    
    if (videoElement.error) {
      switch (videoElement.error.code) {
        case 1: // MEDIA_ERR_ABORTED
          errorMessage = "Video playback was aborted. Please try again.";
          break;
        case 2: // MEDIA_ERR_NETWORK
          errorMessage = "A network error occurred. Please check your connection.";
          break;
        case 3: // MEDIA_ERR_DECODE
          errorMessage = "Video format not supported. Please try a different format.";
          break;
        case 4: // MEDIA_ERR_SRC_NOT_SUPPORTED
          errorMessage = "Video format not supported. Please try MP4, WebM, or Ogg.";
          break;
      }
    }
    
    setError(errorMessage);
    setIsPlaying(false);
  };

  const clearVideo = () => {
    if (videoSource?.startsWith('blob:')) {
      URL.revokeObjectURL(videoSource);
    }
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.removeAttribute('src');
      videoRef.current.load();
    }
    setVideoSource(null);
    setIsPlaying(false);
    setRtspUrl('');
    setError(null);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Live Video Feed</h2>
        <div className="flex items-center space-x-4">
          {videoSource ? (
            <>
              <button
                onClick={handlePlayPause}
                className="flex items-center px-3 py-2 bg-white rounded-lg shadow hover:bg-gray-50"
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 text-gray-700" />
                ) : (
                  <Play className="w-5 h-5 text-gray-700" />
                )}
              </button>
              <button
                onClick={clearVideo}
                className="flex items-center px-3 py-2 bg-red-50 text-red-600 rounded-lg shadow hover:bg-red-100"
              >
                <X className="w-5 h-5" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center px-4 py-2 bg-white rounded-lg shadow hover:bg-gray-50"
              >
                <Upload className="w-5 h-5 mr-2" />
                Upload Video
              </button>
              <button
                onClick={() => setShowRtspInput(!showRtspInput)}
                className="flex items-center px-4 py-2 bg-white rounded-lg shadow hover:bg-gray-50"
              >
                <Link className="w-5 h-5 mr-2" />
                RTSP Stream
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/webm,video/ogg"
                className="hidden"
                onChange={handleFileUpload}
              />
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="mb-4 p-4 bg-red-50 text-red-600 rounded-lg flex items-center">
          <AlertCircle className="w-5 h-5 mr-2" />
          {error}
        </div>
      )}

      {showRtspInput && (
        <div className="mb-6">
          <form onSubmit={handleRtspSubmit} className="flex space-x-4">
            <input
              type="text"
              value={rtspUrl}
              onChange={(e) => setRtspUrl(e.target.value)}
              placeholder="Enter RTSP URL (e.g., rtsp://example.com/stream)"
              className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
            />
            <button
              type="submit"
              className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
            >
              Connect
            </button>
          </form>
        </div>
      )}

      <div className="flex-1 bg-black rounded-lg overflow-hidden relative">
        {videoSource ? (
          <video
            ref={videoRef}
            src={videoSource}
            className="w-full h-full object-contain"
            autoPlay
            playsInline
            onError={handleVideoError}
            controls
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center flex-col">
            <Camera className="w-16 h-16 text-gray-600 mb-4" />
            <span className="text-gray-500">No video feed connected</span>
          </div>
        )}

        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
          <div className="flex items-center justify-between text-white">
            <span>Camera ID: CAM_001</span>
            <span>Resolution: 1920x1080</span>
            <span>FPS: 30</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoDisplay;