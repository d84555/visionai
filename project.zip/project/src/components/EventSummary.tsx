import React from 'react';
import { BarChart2, TrendingUp, AlertTriangle, Clock } from 'lucide-react';

const EventSummary = () => {
  const stats = [
    { title: 'Total Events', value: '1,284', icon: BarChart2, change: '+12%' },
    { title: 'Detection Rate', value: '98.5%', icon: TrendingUp, change: '+3%' },
    { title: 'Critical Alerts', value: '24', icon: AlertTriangle, change: '-8%' },
    { title: 'Avg Response Time', value: '1.2s', icon: Clock, change: '-15%' },
  ];

  return (
    <div className="h-full flex flex-col">
      <h2 className="text-2xl font-semibold mb-6">AI-Powered Event Summary</h2>
      
      <div className="grid grid-cols-2 gap-6 mb-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.title} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-500 mb-1">{stat.title}</p>
                  <p className="text-3xl font-bold">{stat.value}</p>
                </div>
                <Icon className="w-8 h-8 text-red-600" />
              </div>
              <div className="mt-4">
                <span className={`text-sm ${
                  stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'
                }`}>
                  {stat.change} from last week
                </span>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-lg shadow p-6 flex-1">
        <h3 className="text-lg font-semibold mb-4">Event Pattern Analysis</h3>
        <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
          <span className="text-gray-500">Chart visualization will be displayed here</span>
        </div>
        
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-4">Key Insights</h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <span className="w-2 h-2 mt-2 bg-red-600 rounded-full mr-3"></span>
              <p className="text-gray-700">Increased vehicle detection activity during peak hours (8 AM - 10 AM)</p>
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 mt-2 bg-red-600 rounded-full mr-3"></span>
              <p className="text-gray-700">Reduced false positive alerts by 23% through AI model optimization</p>
            </li>
            <li className="flex items-start">
              <span className="w-2 h-2 mt-2 bg-red-600 rounded-full mr-3"></span>
              <p className="text-gray-700">Most common detection: Vehicle (65%), followed by Person (25%)</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default EventSummary;