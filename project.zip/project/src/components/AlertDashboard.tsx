import React from 'react';
import { AlertCircle, Filter } from 'lucide-react';

const AlertDashboard = () => {
  const alerts = [
    { id: 1, timestamp: '2024-03-15 10:30:22', type: 'Object Detected', confidence: 98.5, object: 'Vehicle' },
    { id: 2, timestamp: '2024-03-15 10:29:15', type: 'Motion Detected', confidence: 95.2, object: 'Person' },
    { id: 3, timestamp: '2024-03-15 10:28:03', type: 'Zone Violation', confidence: 99.1, object: 'Vehicle' },
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">Alert Dashboard</h2>
        <button className="flex items-center px-4 py-2 bg-white rounded-lg shadow hover:bg-gray-50">
          <Filter className="w-4 h-4 mr-2" />
          Filter
        </button>
      </div>

      <div className="bg-white rounded-lg shadow flex-1 overflow-hidden">
        <div className="p-4 border-b">
          <div className="grid grid-cols-5 gap-4 font-medium text-gray-700">
            <div>Time</div>
            <div>Event ID</div>
            <div>Type</div>
            <div>Object</div>
            <div>Confidence</div>
          </div>
        </div>
        
        <div className="overflow-auto">
          {alerts.map((alert) => (
            <div key={alert.id} className="grid grid-cols-5 gap-4 p-4 border-b hover:bg-gray-50">
              <div className="text-gray-600">{alert.timestamp}</div>
              <div className="text-gray-900">#{alert.id.toString().padStart(6, '0')}</div>
              <div className="flex items-center">
                <AlertCircle className="w-4 h-4 text-red-600 mr-2" />
                {alert.type}
              </div>
              <div>{alert.object}</div>
              <div className="text-green-600">{alert.confidence}%</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AlertDashboard;