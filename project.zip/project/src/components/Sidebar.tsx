import React from 'react';
import { Camera, AlertCircle, Database, BarChart2, Cpu, Cpu as Gpu, Server } from 'lucide-react';
import Logo from './Logo';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'video', icon: Camera, label: 'Video Feed' },
    { id: 'alerts', icon: AlertCircle, label: 'Alerts' },
    { id: 'events', icon: Database, label: 'Event Log' },
    { id: 'summary', icon: BarChart2, label: 'AI Summary' },
  ];

  return (
    <div className="w-64 bg-white shadow-lg flex flex-col h-full">
      <div className="p-6">
        <div className="flex items-center space-x-3">
          <Logo />
          <div>
            <h1 className="text-2xl font-bold text-red-600">Avianet</h1>
            <p className="text-sm text-gray-500 -mt-1">Vision</p>
          </div>
        </div>
      </div>

      <nav className="mt-6">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center px-6 py-4 text-gray-700 hover:bg-gray-100 ${
                activeTab === item.id ? 'bg-gray-100 border-l-4 border-red-600' : ''
              }`}
            >
              <Icon className="w-5 h-5 mr-3" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="mt-auto p-6 border-t">
        <h3 className="text-sm font-semibold text-gray-600 mb-4">System Information</h3>
        
        {/* GPU Usage */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-1">
            <div className="flex items-center">
              <Gpu className="w-4 h-4 mr-2 text-gray-500" />
              <span className="text-gray-600">GPU Usage</span>
            </div>
            <span className="text-gray-900">85%</span>
          </div>
          <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-red-600 rounded-full" style={{ width: '85%' }}></div>
          </div>
        </div>

        {/* Memory Usage */}
        <div className="mb-4">
          <div className="flex items-center justify-between text-sm mb-1">
            <div className="flex items-center">
              <Server className="w-4 h-4 mr-2 text-gray-500" />
              <span className="text-gray-600">Memory</span>
            </div>
            <span className="text-gray-900">4.2/8 GB</span>
          </div>
          <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
            <div className="h-full bg-red-600 rounded-full" style={{ width: '52.5%' }}></div>
          </div>
        </div>

        {/* Model Information */}
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Cpu className="w-4 h-4 mr-2 text-gray-500" />
              <span className="text-gray-600">Model</span>
            </div>
            <span className="text-gray-900">YOLOv11</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Inference Time</span>
            <span className="text-gray-900">24ms</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-600">FPS</span>
            <span className="text-gray-900">30</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Sidebar;